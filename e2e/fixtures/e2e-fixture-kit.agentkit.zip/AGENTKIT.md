# E2E Fixture Kit

Use this Agent Kit when the user's task matches one of the listed skill triggers.
