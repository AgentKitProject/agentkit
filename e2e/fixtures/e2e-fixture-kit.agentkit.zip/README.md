# E2E Fixture Kit

Disposable fixture kit created and submitted by the AgentKitProject E2E suite
to exercise the submit → validate → cancel journey. Anything named `e2e-*` in
the review queue is test data and safe to delete.
