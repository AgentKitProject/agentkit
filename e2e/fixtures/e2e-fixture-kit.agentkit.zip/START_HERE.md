# E2E Fixture Kit

Disposable fixture kit created by the AgentKitProject E2E suite. Safe to delete.
