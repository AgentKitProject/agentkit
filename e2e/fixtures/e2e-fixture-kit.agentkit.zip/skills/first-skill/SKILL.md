---
id: first-skill
name: First Skill
description: First starter skill.
triggers:
  - first skill
riskLevel: low
---

# First Skill

## Use when

Use this skill when a user asks for the starter workflow.

## Procedure

Clarify the goal, follow the kit instructions, and produce a concise result.

## Output

Return Markdown.
